/*First Moment Business Decision--*/
/*Mean*/
select Avg(QTY) as mean from  scms;
select Avg(CustName) as mean from scms;

/*---------------------------------------------Median-------------------------------------------------------*/
SELECT QTY AS median_Column5
FROM (
SELECT QTY, ROW_NUMBER() OVER (ORDER BY QTY) AS row_num,
COUNT(*) OVER () AS total_count
FROM scms
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;

/*--------------------------------------------Mode----------------------------------------------------*/
SELECT State AS mode_Column3
FROM (SELECT State, COUNT(*) AS frequency FROM scms GROUP BY State ORDER BY frequency DESC LIMIT 1) AS subquery;

SELECT Region AS mode_Column3 FROM (SELECT Region, COUNT(*) AS frequency FROM scms GROUP BY Region
ORDER BY frequency DESC LIMIT 1) AS subquery;

SELECT City AS mode_Column3 FROM (SELECT City, COUNT(*) AS frequency FROM scms GROUP BY City
ORDER BY frequency DESC LIMIT 1) AS subquery;

/*---Second moment business decision-----*/
/*Standard Deviation*/
SELECT STDDEV(QTY) AS QTY_stddev FROM scms;

/*--------------------------------------------Range--------------------------------------*/
SELECT MAX(QTY) - MIN(QTY) AS QTY_range FROM scms;

/*--------------------------------------------Variance---------------------------------------------------*/
SELECT VARIANCE(QTY) AS performance_variance FROM scms;

/*-Third moment Business decision-------------------------*/
/*Skewness*/
SELECT(SUM(POWER(QTY- (SELECT AVG(QTY) FROM scms), 3)) /(COUNT(*) * POWER((SELECT STDDEV(QTY) FROM scms), 3))) 
AS skewness from scms;

/*---Fourth Moment Business Decision----*/
/*Kurtosis*/
SELECT((SUM(POWER(QTY- (SELECT AVG(QTY) FROM scms), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(QTY) FROM scms), 4))) - 3) AS kurtosis
FROM scms;

/*-----------------------------------------------------Data Preprocessing----------------------------------------------------------------------------------*/
/*Duplicates*/
SELECT QTY, COUNT(*) as duplicate_count
FROM scms
GROUP BY QTY
HAVING COUNT(*) > 1;

CREATE TABLE temp_TABLE_NAME AS
SELECT DISTINCT *
FROM scms;
TRUNCATE TABLE scms;
INSERT INTO TABLE_NAME SELECT * FROM temp_TABLE_NAME;
DROP TABLE temp_TABLE_Name;


/*---------------------------------------------------Missing Values---------------------------------*/
SELECT COUNT(*) AS total_rows,
SUM(CASE WHEN QTY IS NULL THEN 1 ELSE 0 END) AS QTY_missing,
SUM(CASE WHEN City IS NULL THEN 1 ELSE 0 END) AS City_missing,
SUM(CASE WHEN State IS NULL THEN 1 ELSE 0 END) AS State_missing,
SUM(CASE WHEN Transaction_Type IS NULL THEN 1 ELSE 0 END) AS TransactionType_missing,
SUM(CASE WHEN WHName IS NULL THEN 1 ELSE 0 END) AS WHName_missing,
SUM(CASE WHEN Date IS NULL THEN 1 ELSE 0 END) AS Date_missing,
SUM(CASE WHEN Region IS NULL THEN 1 ELSE 0 END) AS Region_missing,
SUM(CASE WHEN Product_code IS NULL THEN 1 ELSE 0 END) AS Productcode_missing
FROM scms;

/*------------------------------------------------------OUTLIERS_-----------------------------------------------*/

UPDATE TABLE_Name AS e JOIN (SELECT QTY, NTILE(4) OVER (ORDER BY QTY) AS Column5_quartile
FROM scms) AS subquery ON e.QTY = subquery.QTY SET e.QTY = (SELECT AVG(QTY) FROM (SELECT QTY,NTILE(4) OVER 
(ORDER BY QTY) AS Column5_quartile FROM scms) AS temp WHERE QTY_quartile = subquery.QTY_quartile)
WHERE subquery.QTY_quartile IN (1, 4);